package desenho.segundaDimensao;

public class Simpsons {

}
