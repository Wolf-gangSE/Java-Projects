package real;

import real.filme.Vingadores;

public class Testar {
	
	public static void main(String [] args) {
		Vingadores v = new Vingadores();
		v.setNome("A era de Ultron");
		System.out.println(v.getNome());
	}

}
