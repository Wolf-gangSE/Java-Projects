package real.filme;

public class Vingadores extends Filme {
	private String hqDeOrigem;
	
	public String getHqDeOrigem() {
		return hqDeOrigem;
	}
	
	public void setHqDeOrigem() {
		this.nome = nome;
	}

}
