package real.filme;

public abstract class  Filme {
	protected String nome;
	protected int ano;
	
	public String getNome() {
		return this.nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}

}
