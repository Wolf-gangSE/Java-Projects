package game.primeiraPessoa;

public class Doom {

}
