package ensino;

public class Professor extends Humano implements Educador{
	protected String nome;
	
	public Professor(String nomeH, String nomeP) {
		super.nome = nomeH;
		this.nome = nomeP;
		System.out.println(super.nome);
		System.out.println(this.nome);
	}

	public void Ensinar() {

	}
	

}
