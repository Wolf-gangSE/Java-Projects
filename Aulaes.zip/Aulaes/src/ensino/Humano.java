package ensino;

public abstract class Humano implements SerVivo {
	protected String nome;
	
	public void respirar() {
		
	}

}
