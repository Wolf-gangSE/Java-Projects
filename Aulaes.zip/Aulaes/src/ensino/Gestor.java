package ensino;

public interface Gestor {
	void gerir();
	

}
