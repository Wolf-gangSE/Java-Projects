package ensino;

public interface SerVivo {
	void respirar();
	

}
