package ensino;

public interface Educador {
	void Ensinar();
	

}
