package ensino;

public class Coordenador extends Professor implements Gestor{
	private String nome;

	public Coordenador(String nomeH, String nomeP, String nomeC) {
		super(nomeH, nomeP);
		this.nome = nomeC;
		System.out.println(this.nome);
		
	}
	
	public void gerir() {
		
	}
	
	public static void main(String[] args) {
		Coordenador c = new Coordenador("Carlo", "Marcelo", "Revoredo");
	}

}
