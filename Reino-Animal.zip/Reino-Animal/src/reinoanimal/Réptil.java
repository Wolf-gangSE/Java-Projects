package reinoanimal;

public class R�ptil extends Animal implements Terrestre, Aqu�tico {

	public R�ptil(String nome, String classe, String alimentacao) {
		super(nome, classe, alimentacao);
	}

	public void nadar() {
		
	}

	public void caminhar() {
		
	}
	public static void main(String[] args) {
		R�ptil r = new R�ptil("Cobra", "R�ptil", "Carn�voro");
	}

}