package reinoanimal;

public interface Aqu�tico {
	public void nadar();

}
