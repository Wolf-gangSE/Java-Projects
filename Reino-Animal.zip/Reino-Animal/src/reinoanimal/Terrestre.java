package reinoanimal;

public interface Terrestre {
	public void caminhar();

}
