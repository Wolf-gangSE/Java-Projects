package reinoanimal;

public class Mam�fero extends Animal implements Terrestre, Aqu�tico, A�reo, Can�deo, Felino, Roedor {

	public Mam�fero(String nome, String classe, String alimentacao) {
		super(nome, classe, alimentacao);
	}

	public void nadar() {
	
	}

	public void caminhar() {
		
	}

	public void voar() {
		
	}
	
	public static void main(String[] args) {
		Mam�fero m = new Mam�fero("Humano", "Mam�fero", "Omn�voro");
	}

}
	