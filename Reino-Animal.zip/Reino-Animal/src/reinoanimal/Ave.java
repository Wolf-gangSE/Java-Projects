package reinoanimal;

public class Ave extends Animal implements A�reo {

	public Ave(String nome, String classe, String alimentacao) {
		super(nome, classe, alimentacao);
	}

	public void voar() {
	}
	public static void main(String[] args) {
		Ave a = new Ave("Beija-Flor", "Ave", "Herb�voro");
	}
}
