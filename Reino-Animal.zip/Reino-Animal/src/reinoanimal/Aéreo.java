package reinoanimal;

public interface A�reo {
	public void voar();

}
