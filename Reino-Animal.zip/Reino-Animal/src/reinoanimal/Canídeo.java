package reinoanimal;

public interface Can�deo {
	static void latir() {
		System.out.println("Este animal late.");
	}

}
