package reinoanimal;

public interface Felino {
	static void farejar( ) {
		System.out.println("Este animal fareja.");
	}

}
