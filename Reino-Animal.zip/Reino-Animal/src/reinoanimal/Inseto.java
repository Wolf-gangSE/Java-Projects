package reinoanimal;

public class Inseto extends Animal implements Terrestre, A�reo {

	public Inseto(String nome, String classe, String alimentacao) {
		super(nome, classe, alimentacao);
	}

	public void voar() {
		
	}

	public void caminhar() {
		
	}
	public static void main(String[] args) {
		Inseto i = new Inseto("Formiga", "Inseto", "Omn�vora");
	}

}