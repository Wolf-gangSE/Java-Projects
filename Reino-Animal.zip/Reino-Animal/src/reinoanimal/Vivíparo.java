package reinoanimal;

public interface Viv�paro {
	static void parir() {
		System.out.println("Este animal pare seus descendentes.");
		
	}

}
