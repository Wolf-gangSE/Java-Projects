package reinoanimal;

public interface Ov�paro {
	static void chocar() {
		System.out.println("Este animal choca ovos.");
	}

}
