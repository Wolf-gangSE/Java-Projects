package reinoanimal;

public class Peixe extends Animal implements Aqu�tico{

	public Peixe(String nome, String classe, String alimentacao) {
		super(nome, classe, alimentacao);
	}

	public void nadar() {
	}
	public static void main(String[] args) {
		Peixe p = new Peixe("Tubar�o", "Peixe", "Carn�voro");
	}

}
