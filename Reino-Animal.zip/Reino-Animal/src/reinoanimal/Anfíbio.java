package reinoanimal;

public class Anf�bio extends Animal implements Aqu�tico, Terrestre {

	public Anf�bio(String nome, String classe, String alimentacao) {
		super(nome, classe, alimentacao);
	}

	public void caminhar() {
		
	}

	public void nadar() {
		
	}
	public static void main(String[] args) {
		Anf�bio a = new Anf�bio("Sapo", "Anf�bio", "Carn�voros");
	}

}
