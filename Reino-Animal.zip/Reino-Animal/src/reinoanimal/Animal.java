package reinoanimal;

public abstract class Animal {
	protected String nome;
	protected String classe;
	protected String alimentacao;
	
	 
	public Animal(String nome, String classe, String alimentacao) {
		this.nome = nome;
		this.classe = classe;
		this.alimentacao = alimentacao;
		
	} 
}
