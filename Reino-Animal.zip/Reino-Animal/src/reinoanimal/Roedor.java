package reinoanimal;

public interface Roedor {
	static void roer() {
		System.out.println("Este animal r�i.");
	}

}
