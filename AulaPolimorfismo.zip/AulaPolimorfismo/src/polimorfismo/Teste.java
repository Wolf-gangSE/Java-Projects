package polimorfismo;

public class Teste {
	private int idade = 10;
	private  static int id = 20;
	
	public static void main(String[] args) {
		Teste t = new Teste();
		System.out.println(t.idade+"");
		System.out.println(id+"");
	}

}
