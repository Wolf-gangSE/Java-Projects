package polimorfismo;

import java.util.Scanner;

public class Exemplo {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		System.out.println("Digite um número: ");
		String digitado = s.next();
		
		if (digitado.equals("0")) {
			System.out.println("zero");
			
		}
		if (digitado.equals("1")) {
			System.out.println("hum");
		}
		
		if (digitado.equals("2")) {
			System.out.println("dois");
		}
		
		s.close();
	}

}
