package polimorfismo.v1;

public interface Terrestre {
	void andar();

}
