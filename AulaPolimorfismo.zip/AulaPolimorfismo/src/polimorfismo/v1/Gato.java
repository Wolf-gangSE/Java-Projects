package polimorfismo.v1;

public class Gato extends Animal implements Terrestre{
	
	public Gato() {
		super(false);
	}
	
	public void andar() {
		System.out.println(this.getNome() + " se move com 4 patas.");

}
	
}
