package polimorfismo.v1;

import java.util.Scanner;

public class Principal {
	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		System.out.println("[0] Humano [1] Cachorro [2] Gato");
		String digitado = s.nextLine();
		
		
		if (digitado.equals("0")) {
			System.out.println("Informe o nome do humano:");
			String nome = s.nextLine();
			
			Humano h = new Humano();
			
			
		}
		
		if (digitado.equals("1")) {
			System.out.println("Informe o nome do cahorro:");
			String nome = s.nextLine();
			
			System.out.println(nome + " é um cahorro.");
			System.out.println(nome + " se move com 4 pernas.");
			System.out.println(nome + " se comunica latindo.");
			System.out.println(nome + " é um animal irracional");
			
			
		}
		
		if (digitado.equals("2")) {
			System.out.println("Informe o nome do gato:");
			String nome = s.nextLine();
			
			System.out.println(nome + " é um gato.");
			System.out.println(nome + " se move com 4 pernas.");
			System.out.println(nome + " se comunica miando.");
			System.out.println(nome + " é um animal irracional");
			
		}
	}
	
	void mover() {
		
	}

}
