package polimorfismo.v1;

public abstract class Animal {
	public String nome;
	public Boolean racional;
	
	public Animal(Boolean isracional) {
		
		
		
	}
	
	if (isracional.equals(true)) {
		
	}
	
	if (isracional.equals(false)) {
		
	}

}
