package polimorfismo.v1;

public class Cachorro extends Animal implements Terrestre{
	
	public Cachorro() {
		super(false);
	}
	
	public void andar() {
		System.out.println(this.getNome() + " se move com 4 patas.");
		
	}

}
