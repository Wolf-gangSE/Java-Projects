package polimorfismo.v1;

public class Humano extends Animal implements Terrestre {
	
	public Humano() {
		super(true);
	}
	public void andar() {
		System.out.println(this.getNome() + " se move com 2 pernas.");
	}

}
